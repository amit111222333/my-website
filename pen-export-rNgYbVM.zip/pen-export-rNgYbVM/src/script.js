// script.js
document.getElementById('discordForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const line1 = document.getElementById('line1').value;
    const line2 = document.getElementById('line2').value;
    const followers = document.getElementById('followers').value;

    if (followers > 5000) {
        alert('יש לבחור מספר עד 5000');
        return;
    }

    const webhookUrl = 'https://discord.com/api/webhooks/1251147304208039977/9W0JPMP4DRwtEXzgOx10UcssZu278vnmLSE5I1L-8pGgTM5UyZcxFhG-NEWwd7za_Mqc';  // שים כאן את כתובת ה-Webhook שלך

    const message = {
        content: `שורה ראשונה: ${line1}\nשורה שנייה: ${line2}\nמספר עוקבים: ${followers}`
    };

    fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
    })
    .then(response => {
        if (response.ok) {
            alert('ההודעה נשלחה בהצלחה!');
        } else {
            alert('הייתה בעיה בשליחת ההודעה.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('הייתה בעיה בשליחת ההודעה.');
    });
});
